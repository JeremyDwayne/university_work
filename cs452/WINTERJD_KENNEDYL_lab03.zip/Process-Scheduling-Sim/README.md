# Process-Scheduling-Sim
_Lab 03, CS452_
Jeremy Winterberg
Matthew Kennedy

# How To Run
make

./scheduler

Follow on screen instructions
