public interface StatementListener {
  void onPostEval();
}
