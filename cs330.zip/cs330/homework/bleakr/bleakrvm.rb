class BleakrVM
  attr_accessor :input, :output, :registers, :instructions, :labels

  def initialize (source, input)
    @input = []
    @instructions = []
    @output = []
    @labels = {}
    @registers = { 
      "pc" => 0, "ic" => 0, "r0" => 0, "r1" => 0, "r2" => 0, "r3" => 0, "r4" => 0, 
      "r5" => 0, "r6" => 0, "r7" => 0, "r8" => 0, "r9" => 0, 
    }
    File.open(input, "r").readlines.each do |line|
      @input << line.tr("\n", "").to_i
    end
    count = 0
    File.open(source, "r").readlines.each do |line|
      if !(regex = line[/(?<=<-\s)\w+/]).nil?
        @labels["#{regex.tr("\n", "")}"] = count
      end
      @instructions << line
      count += 1
    end
  end

  def resolve_lvalue (expression)
    bracket = expression[/(?<=\[).+?(?=\])/]
    no_bracket = expression[/^r\d$/]
    if !no_bracket.nil?
      expression
    elsif !bracket.nil?
      "r#{@registers[bracket]}"
    else
      nil
    end
  end

  def resolve_rvalue (expression)
    bracket = expression[/(?<=\[).+?(?=\])/]
    no_bracket = expression[/^r\d$/]
    integer = expression[/^.*$/]
    if !no_bracket.nil?
      @registers[expression].to_i
    elsif !bracket.nil?
      @registers["r#{@registers[bracket]}"].to_i
    elsif !integer.nil?
      integer.to_i
    else
      nil
    end
  end

  def step
    raise "Empty Instruction Set" if @instructions.empty?
    raise "Nil Instruction" if @instructions[@registers["pc"]].nil? 
    if !@instructions[@registers["pc"]].match(/(?<=<-\s)\w+/).nil?
      jump = @instructions[@registers["pc"]].split(" <- ")
      instruction = jump.first.split(" ")
      label = jump.last
    else
      instruction = @instructions[@registers["pc"]]
      instruction = instruction.chomp("\n").split(" ")
    end

    case instruction.first
    when "add"
      @registers[resolve_lvalue(instruction[1])] += resolve_rvalue(instruction[2]).to_i
      inc_pc
    when "sub"
      @registers[resolve_lvalue(instruction[1])] -= resolve_rvalue(instruction[2]).to_i
      inc_pc
    when "inc"
      @registers[resolve_lvalue(instruction[1])] += 1
      inc_pc
    when "dec"
      @registers[resolve_lvalue(instruction[1])] -= 1
      inc_pc
    when "input"
      raise "Whoops, theres no more input to be read" if (@registers["ic"] >= @input.size)

      @registers[resolve_lvalue(instruction[1])] = @input[@registers["ic"]].to_i
      inc_pc
      inc_ic
    when "output"
      @output << resolve_rvalue(instruction[1]).to_i
      inc_pc
    when "store"
      @registers[resolve_lvalue(instruction[1])] = resolve_rvalue(instruction[2]).to_i
      inc_pc
    when "jmp"
      @registers["pc"] = @labels[instruction[1]].to_i
    when "jpos"
      @registers["pc"] = (resolve_rvalue(instruction[1]) > 0) ? @labels[instruction[2]] : @registers["pc"].to_i + 1
    when "jneg"
      @registers["pc"] = (resolve_rvalue(instruction[1]) < 0) ? @labels[instruction[2]] : @registers["pc"].to_i + 1
    when "jzilch"
      @registers["pc"] = (resolve_rvalue(instruction[1]) == 0) ? @labels[instruction[2]] : @registers["pc"].to_i + 1
    end
  end

  def reset
    @output = []
    @registers.each do |k,v|
      @registers[k] = 0
    end
  end

  def dump
    puts "Input:\n #{@input}"
    puts "Instructions:\n\t#{@instructions}"
    puts "Output:\n #{@output}"
    puts "Registers:\n #{@registers}"
    puts "Labels:\n #{@labels}"
  end

  def inc_pc
    @registers["pc"] += 1
  end

  def inc_ic
    @registers["ic"] += 1
  end

end
