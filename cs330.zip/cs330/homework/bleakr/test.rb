include Java
import javax.swing.JFrame
import javax.swing.JPanel
import javax.swing.JButton
import javax.swing.JList
import javax.swing.JScrollPane

class Test < JFrame
  def initialize
    super "Test"
    # # Panel
    # panel = JPanel.new
    # self.getContentPane.add panel
    # panel.setLayout nil
    
    # # Lists
    # instructions = JList.new
    # registers = JList.new
    # input = JList.new
    # output = JList.new

    # # Scroll Panes
    # inst_pane = JScrollPane.new
    # reg_pane = JScrollPane.new
    # input_pane = JScrollPane.new
    # output_pane = JScrollPane.new

    # inst_pane.getViewport.add instructions
    # reg_pane.getViewport.add registers
    # input_pane.getViewport.add input
    # output_pane.getViewport.add output

    # panel.add inst_pane
    # panel.add reg_pane
    # panel.add input_pane
    # panel.add output_pane

    # # Buttons
    # step_button = JButton.new "Next Step"
    # reset_button = JButton.new "Reset"

    # panel.add step_button
    # panel.add reset_button

    # JFrame Settings
    self.setSize 300, 200
    self.setDefaultCloseOperation JFrame::EXIT_ON_CLOSE
    self.setLocationRelativeTo nil
    self.setVisible true
  end
end

Test.new
