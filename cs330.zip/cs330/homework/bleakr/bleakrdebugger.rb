#!/usr/bin/env jruby
# Pass it the files to test as params. ./bleakerdebugger path_to_instructions  path_to_input

include Java
import javax.swing.JFrame
import javax.swing.JPanel
import javax.swing.JButton
import javax.swing.JLabel
import javax.swing.JList
import javax.swing.JScrollPane
import java.awt.GridBagLayout
import java.awt.GridBagConstraints
import java.awt.BorderLayout
import java.awt.Font
import java.awt.event.ActionListener
require "bleakrvm"

class BleakrDebugger < JFrame

  def initialize (vm = nil)
    super "BleakrDebugger"

    self.getContentPane.setLayout BorderLayout.new
    @panel = JPanel.new GridBagLayout.new
    @panel_components = {}
    self.getContentPane.add @panel, BorderLayout::CENTER
    gbc = GridBagConstraints.new

    # Set Labels, Fonts and Lists
    ins_label = JLabel.new "Instructions"
    ins_label.setFont Font.new("Sans Serif", Font::BOLD, 16)
    instructions = JList.new vm.instructions.to_java
    instructions.setSelectedIndex 0
    ins_list_pane = JScrollPane.new instructions
    @panel_components["instructions"] = instructions

    reg_label = JLabel.new "Registers"
    reg_label.setFont Font.new("Sans Serif", Font::BOLD, 16)
    registers = JList.new vm.registers.to_a.to_java
    reg_list_pane = JScrollPane.new registers
    @panel_components["registers"] = registers

    inp_label = JLabel.new "Input"
    inp_label.setFont Font.new("Sans Serif", Font::BOLD, 16)
    input = JList.new vm.input.to_java
    inp_list_pane = JScrollPane.new input
    @panel_components["input"] = input

    out_label = JLabel.new "Output"
    out_label.setFont Font.new("Sans Serif", Font::BOLD, 16)
    output = JList.new(vm.output.to_java)
    out_list_pane = JScrollPane.new output
    @panel_components["output"] = output

    # Start of UI Building using Grid Bag Layout
    gbc.fill = GridBagConstraints::BOTH
    gbc.weightx = 0.2
    gbc.weighty = 0.0
    gbc.gridwidth = 2
    gbc.gridx = 0
    gbc.gridy = 0
    @panel.add ins_label, gbc

    gbc.weighty = 0.8
    gbc.gridy = 1
    @panel.add ins_list_pane, gbc

    gbc.weighty = 0.0
    gbc.gridx = 2
    gbc.gridy = 0
    @panel.add reg_label, gbc

    gbc.weighty = 0.8
    gbc.gridy = 1
    @panel.add reg_list_pane, gbc
    
    gbc.weighty = 0.0
    gbc.gridx = 4
    gbc.gridy = 0
    @panel.add inp_label, gbc

    gbc.weighty = 0.8
    gbc.gridy = 1
    @panel.add inp_list_pane, gbc

    gbc.weighty = 0.0
    gbc.gridx = 6
    gbc.gridy = 0
    @panel.add out_label, gbc

    gbc.weighty = 0.8
    gbc.gridy = 1
    @panel.add out_list_pane, gbc

    # Next and Reset Buttons
    stepper = JButton.new "Next Step"
    # stepper.addActionListener ClickAction.new 
    stepper.add_action_listener { |e| 
      vm.step
      update_lists(vm, e)
    }

    reset = JButton.new "Reset"
    reset.add_action_listener { |e| 
      vm.reset
      update_lists(vm, e)
    }

    gbc.fill = GridBagConstraints::HORIZONTAL
    gbc.weighty = 0.0
    gbc.gridx = 0
    gbc.gridy = 8
    @panel.add stepper, gbc

    gbc.gridx = 2
    gbc.gridy = 8
    @panel.add reset, gbc

    # Default JFrame settings
    self.setDefaultCloseOperation JFrame::EXIT_ON_CLOSE
    self.setSize 720, 400
    self.setLocationRelativeTo nil
    self.setVisible true
  end

  def update_lists(vm, event)
    if event.getActionCommand == "Next Step"
      pc = vm.registers["pc"]
      @panel_components["instructions"].setSelectedIndex pc
      @panel_components["registers"].setListData(vm.registers.to_a.to_java)
      @panel_components["output"].setListData(vm.output.to_a.to_java)
    else
      set_lists(vm) 
    end
  end

  def set_lists(vm)
    @panel_components.each do |key, component|
      data = vm.send key
      if key == "registers"
        data = data.to_a
      end
      component.setListData(data.to_java)
    end
    @panel_components["instructions"].setSelectedIndex 0
  end

end
BleakrDebugger.new(BleakrVM.new(ARGV[0], ARGV[1]))
