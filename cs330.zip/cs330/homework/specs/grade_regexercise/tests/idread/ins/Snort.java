public class Snort {
  private void embiggen() {
  }
}
