import java.io.FileNotFoundException;
import java.awt.List;
import java.awt.geom.*;

public class Goo {
  
}
