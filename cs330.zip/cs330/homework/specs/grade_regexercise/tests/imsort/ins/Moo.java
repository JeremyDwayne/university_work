public class Moo {
  // import B
  // import A
}
