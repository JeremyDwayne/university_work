import java.util.Scanner;
import java.lang.String;

public class Foo {
  
}
