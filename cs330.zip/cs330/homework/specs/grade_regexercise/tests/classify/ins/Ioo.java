package com.google.tsp;

import java.util.Scanner;

public class Ioo {
  
}
