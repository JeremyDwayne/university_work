public class Moo {
  
}

class Hoo {
}
