package a.b.c.x.y.z;

public abstract interface Contract {
  void onEvent(); 
}
