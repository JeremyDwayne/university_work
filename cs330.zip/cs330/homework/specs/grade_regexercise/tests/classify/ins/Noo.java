// Insert license here.

public class Poo {
  // An inner class.
  public class Noo {
  }
}
