@Annotated
public final strictfp class Modifiers {
  public void foo() {} 
}
