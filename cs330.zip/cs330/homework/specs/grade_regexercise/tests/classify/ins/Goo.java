public class Goop {
  
}
