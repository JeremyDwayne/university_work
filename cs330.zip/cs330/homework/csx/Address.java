public class Address {
  public int column, row;
  public boolean column_lock, row_lock;

  public Address(int column, boolean column_lock, int row, boolean row_lock){
    //if column_lock or row_lock is true, the respective locked component will not be shifted 
    this.column = column;
    this.column_lock = column_lock;
    this.row = row;
    this.row_lock = row_lock;
  }
  
  public Address(String description){
    // parse description into column/row and respective locks
  }

  public int getColumn(){
    return column;
  }

  public int getRow(){
    return row;
  }

  public Address translate(int column_offset, int row_offset){
    int temp_column = 0;
    int temp_row = 0;
    if (column_lock)
      temp_row = row + row_offset;
    if (row_lock)
      temp_column = column + column_offset;
    return new Address(temp_column, column_lock, temp_row, row_lock);
  }

}
