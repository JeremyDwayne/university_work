package csx;

public abstract class Expr{
  private int precedence;

  public Expr(int precedence){
    this.precedence = precedence;
  }

  public abstract Expr evaluate(SpreadsheetModel model);
  public abstract Expr translate(int col_offset, int row_offset);
  public abstract String toSource();
  public abstract int toInteger() throws UnsupportedOperationException;
  public abstract double toReal() throws UnsupportedOperationException;
  public abstract String toString() throws UnsupportedOperationException;
  public int getPrecedence() { return precedence; };

}
