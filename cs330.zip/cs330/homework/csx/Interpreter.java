package csx;

import org.antlr.v4.runtime.CommonTokenStream;
import java.io.IOException;
import java.io.FileInputStream;
import java.io.File;
import java.util.Stack;
import org.antlr.v4.runtime.tree.ParseTreeWalker;
import org.antlr.v4.runtime.tree.ParseTree;
import org.antlr.v4.runtime.ANTLRInputStream;
import java.util.Scanner;

public class Interpreter extends CSXBaseListener {
  public static void main(String[] args) throws IOException{
    ANTLRInputStream ais = new ANTLRInputStream(new FileInputStream(new File(args[0])));
    CSXLexer lexer = new CSXLexer(ais);
    CommonTokenStream tokens = new CommonTokenStream(lexer);
    CSXParser parser = new CSXParser(tokens);

    ParseTree tree = parser.program();

    ParseTreeWalker walker = new ParseTreeWalker();
    Interpreter interpreter = new Interpreter();
    walker.walk(interpreter, tree);
  }

  public static Expr parseToAST(String expression){
    return null;
  }
}
