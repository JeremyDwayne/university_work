package csx;

public abstract class ExprPrimitive extends Expr {
  private int precedence;

  public ExprPrimitive(){
    this.precedence = 60;
  }

  public String toSource(){
    return null;
  }
}
