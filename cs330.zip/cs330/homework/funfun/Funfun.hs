module Funfun where

import Data.Function.Memoize
import Data.List
import Data.Ord
import Data.Function

twoByTwo :: [a] -> [(a,a)]
twoByTwo [] = []
twoByTwo (_:[]) = []
twoByTwo (first:second:rest) = (first,second) : twoByTwo rest

sumOfSquares :: (Num a) => [a] -> a
sumOfSquares = sum . map (^2)

squareOfSum :: (Num a) => [a] -> a
squareOfSum = (^2) . sum

squmDiff :: Int -> Int
squmDiff n = squareOfSum [1..n] - sumOfSquares [1..n]

mode :: Ord a => [a] -> a
mode = head . maximumBy (comparing length) . group . sort

indices :: Eq a => [a] -> [a] -> [Int]
indices list1 list2 = findIndices (\x -> isPrefixOf list1 x) (tails list2)

flatten2 :: [[a]] -> [a]
flatten2 = foldr (flip (foldr (:))) ([])

nroutes :: Integer -> Integer -> Integer
nroutes = memoize2 route 
  where 
    route :: Integer -> Integer -> Integer
    route w h
      | w == 0 = 1
      | h == 0 = 1
      | otherwise = nroutes w (h-1) + nroutes (w-1) h

type XY = (Double,Double)

translate :: XY -> XY -> XY
translate offset point = ((fst offset) + (fst point),(snd offset) + (snd point))

scale :: XY -> XY -> XY
scale scale_factor point = ((fst scale_factor) * (fst point),(snd scale_factor) * (snd point))

-- Helper to convert to radians
toRad theta = theta * pi / 180

rotate :: Double -> XY -> XY
rotate theta point = (fst point * cos (toRad theta) - snd point * sin (toRad theta),fst point * sin (toRad theta) + snd point * cos (toRad theta))

transformAll :: (a -> XY) -> [a] -> [XY]
transformAll function point = map function point 

gauntlet :: [(XY -> XY)] -> XY -> XY 
gauntlet [] y = y
gauntlet (first:rest) point =  gauntlet rest (first point)

gauntletAll :: [(XY -> XY)] -> [XY] -> [XY]
gauntletAll [] [y] = [y]
gauntletAll flist plist = map (gauntlet flist) plist
